import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Sport } from '../../../modules/sport/domain'

import { Team } from '../../../modules/team/domain'

import { LiveScore } from '../../../modules/liveScore/domain'

import { HistoricalData } from '../../../modules/historicalData/domain'

import { MultimediaContent } from '../../../modules/multimediaContent/domain'

@Entity()
export class Match {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  scheduleTime?: string

  @Column({ nullable: true })
  location?: string

  @Column({ nullable: true })
  sportId?: string

  @ManyToOne(() => Sport, parent => parent.matchs)
  @JoinColumn({ name: 'sportId' })
  sport?: Sport

  @Column({ nullable: true })
  team1Id?: string

  @ManyToOne(() => Team, parent => parent.matchsAsTeam1)
  @JoinColumn({ name: 'team1Id' })
  team1?: Team

  @Column({ nullable: true })
  team2Id?: string

  @ManyToOne(() => Team, parent => parent.matchsAsTeam2)
  @JoinColumn({ name: 'team2Id' })
  team2?: Team

  @OneToMany(() => LiveScore, child => child.match)
  liveScores?: LiveScore[]

  @OneToMany(() => HistoricalData, child => child.match)
  historicalDatas?: HistoricalData[]

  @OneToMany(() => MultimediaContent, child => child.match)
  multimediaContents?: MultimediaContent[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
