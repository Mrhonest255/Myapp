import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MatchDomainModule } from '../domain'
import { MatchController } from './match.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { MatchBySportController } from './matchBySport.controller'

import { TeamDomainModule } from '../../../modules/team/domain'

import { MatchByTeamController } from './matchByTeam.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MatchDomainModule,

    SportDomainModule,

    TeamDomainModule,
  ],
  controllers: [MatchController, MatchBySportController, MatchByTeamController],
  providers: [],
})
export class MatchApplicationModule {}
