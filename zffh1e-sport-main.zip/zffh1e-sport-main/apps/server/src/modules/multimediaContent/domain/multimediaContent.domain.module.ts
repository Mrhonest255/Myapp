import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { MultimediaContentDomainFacade } from './multimediaContent.domain.facade'
import { MultimediaContent } from './multimediaContent.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([MultimediaContent]),
    DatabaseHelperModule,
  ],
  providers: [MultimediaContentDomainFacade, MultimediaContentDomainFacade],
  exports: [MultimediaContentDomainFacade],
})
export class MultimediaContentDomainModule {}
