import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { MultimediaContent } from './multimediaContent.model'

import { Sport } from '../../sport/domain'

import { Match } from '../../match/domain'

@Injectable()
export class MultimediaContentDomainFacade {
  constructor(
    @InjectRepository(MultimediaContent)
    private repository: Repository<MultimediaContent>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<MultimediaContent>): Promise<MultimediaContent> {
    return this.repository.save(values)
  }

  async update(
    item: MultimediaContent,
    values: Partial<MultimediaContent>,
  ): Promise<MultimediaContent> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: MultimediaContent): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<MultimediaContent> = {},
  ): Promise<MultimediaContent[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<MultimediaContent> = {},
  ): Promise<MultimediaContent> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyBySport(
    item: Sport,
    queryOptions: RequestHelper.QueryOptions<MultimediaContent> = {},
  ): Promise<MultimediaContent[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('sport')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sportId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByMatch(
    item: Match,
    queryOptions: RequestHelper.QueryOptions<MultimediaContent> = {},
  ): Promise<MultimediaContent[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('match')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        matchId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
