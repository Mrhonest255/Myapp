export namespace MultimediaContentApplicationEvent {
  export namespace MultimediaContentCreated {
    export const key = 'multimediaContent.application.multimediaContent.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
