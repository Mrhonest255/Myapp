import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class MultimediaContentCreateDto {
  @IsString()
  @IsOptional()
  type?: string

  @IsString()
  @IsOptional()
  url?: string

  @IsString()
  @IsOptional()
  description?: string

  @IsString()
  @IsOptional()
  sportId?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class MultimediaContentUpdateDto {
  @IsString()
  @IsOptional()
  type?: string

  @IsString()
  @IsOptional()
  url?: string

  @IsString()
  @IsOptional()
  description?: string

  @IsString()
  @IsOptional()
  sportId?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
