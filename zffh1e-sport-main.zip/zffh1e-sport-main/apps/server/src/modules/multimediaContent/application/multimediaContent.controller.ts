import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  MultimediaContent,
  MultimediaContentDomainFacade,
} from '@server/modules/multimediaContent/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { MultimediaContentApplicationEvent } from './multimediaContent.application.event'
import {
  MultimediaContentCreateDto,
  MultimediaContentUpdateDto,
} from './multimediaContent.dto'

@Controller('/v1/multimediaContents')
export class MultimediaContentController {
  constructor(
    private eventService: EventService,
    private multimediaContentDomainFacade: MultimediaContentDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items =
      await this.multimediaContentDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: MultimediaContentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.multimediaContentDomainFacade.create(body)

    await this.eventService.emit<MultimediaContentApplicationEvent.MultimediaContentCreated.Payload>(
      MultimediaContentApplicationEvent.MultimediaContentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:multimediaContentId')
  async findOne(
    @Param('multimediaContentId') multimediaContentId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.multimediaContentDomainFacade.findOneByIdOrFail(
      multimediaContentId,
      queryOptions,
    )

    return item
  }

  @Patch('/:multimediaContentId')
  async update(
    @Param('multimediaContentId') multimediaContentId: string,
    @Body() body: MultimediaContentUpdateDto,
  ) {
    const item =
      await this.multimediaContentDomainFacade.findOneByIdOrFail(
        multimediaContentId,
      )

    const itemUpdated = await this.multimediaContentDomainFacade.update(
      item,
      body as Partial<MultimediaContent>,
    )
    return itemUpdated
  }

  @Delete('/:multimediaContentId')
  async delete(@Param('multimediaContentId') multimediaContentId: string) {
    const item =
      await this.multimediaContentDomainFacade.findOneByIdOrFail(
        multimediaContentId,
      )

    await this.multimediaContentDomainFacade.delete(item)

    return item
  }
}
