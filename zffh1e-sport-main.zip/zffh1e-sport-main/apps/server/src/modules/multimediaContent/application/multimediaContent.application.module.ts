import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MultimediaContentDomainModule } from '../domain'
import { MultimediaContentController } from './multimediaContent.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { MultimediaContentBySportController } from './multimediaContentBySport.controller'

import { MatchDomainModule } from '../../../modules/match/domain'

import { MultimediaContentByMatchController } from './multimediaContentByMatch.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MultimediaContentDomainModule,

    SportDomainModule,

    MatchDomainModule,
  ],
  controllers: [
    MultimediaContentController,

    MultimediaContentBySportController,

    MultimediaContentByMatchController,
  ],
  providers: [],
})
export class MultimediaContentApplicationModule {}
