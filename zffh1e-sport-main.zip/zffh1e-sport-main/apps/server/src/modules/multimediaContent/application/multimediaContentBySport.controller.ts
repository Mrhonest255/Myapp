import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { MultimediaContentDomainFacade } from '@server/modules/multimediaContent/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { MultimediaContentApplicationEvent } from './multimediaContent.application.event'
import { MultimediaContentCreateDto } from './multimediaContent.dto'

import { SportDomainFacade } from '../../sport/domain'

@Controller('/v1/sports')
export class MultimediaContentBySportController {
  constructor(
    private sportDomainFacade: SportDomainFacade,

    private multimediaContentDomainFacade: MultimediaContentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/sport/:sportId/multimediaContents')
  async findManySportId(
    @Param('sportId') sportId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.sportDomainFacade.findOneByIdOrFail(sportId)

    const items = await this.multimediaContentDomainFacade.findManyBySport(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/sport/:sportId/multimediaContents')
  async createBySportId(
    @Param('sportId') sportId: string,
    @Body() body: MultimediaContentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, sportId }

    const item = await this.multimediaContentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MultimediaContentApplicationEvent.MultimediaContentCreated.Payload>(
      MultimediaContentApplicationEvent.MultimediaContentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
