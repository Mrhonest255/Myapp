import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { MultimediaContentDomainFacade } from '@server/modules/multimediaContent/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { MultimediaContentApplicationEvent } from './multimediaContent.application.event'
import { MultimediaContentCreateDto } from './multimediaContent.dto'

import { MatchDomainFacade } from '../../match/domain'

@Controller('/v1/matchs')
export class MultimediaContentByMatchController {
  constructor(
    private matchDomainFacade: MatchDomainFacade,

    private multimediaContentDomainFacade: MultimediaContentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/match/:matchId/multimediaContents')
  async findManyMatchId(
    @Param('matchId') matchId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.matchDomainFacade.findOneByIdOrFail(matchId)

    const items = await this.multimediaContentDomainFacade.findManyByMatch(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/match/:matchId/multimediaContents')
  async createByMatchId(
    @Param('matchId') matchId: string,
    @Body() body: MultimediaContentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, matchId }

    const item = await this.multimediaContentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MultimediaContentApplicationEvent.MultimediaContentCreated.Payload>(
      MultimediaContentApplicationEvent.MultimediaContentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
