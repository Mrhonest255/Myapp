import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Sport } from '../../../modules/sport/domain'

import { Player } from '../../../modules/player/domain'

import { Match } from '../../../modules/match/domain'

@Entity()
export class Team {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  name?: string

  @Column({ nullable: true })
  achievements?: string

  @Column({ nullable: true })
  sportId?: string

  @ManyToOne(() => Sport, parent => parent.teams)
  @JoinColumn({ name: 'sportId' })
  sport?: Sport

  @OneToMany(() => Player, child => child.team)
  players?: Player[]

  @OneToMany(() => Match, child => child.team1)
  matchsAsTeam1?: Match[]

  @OneToMany(() => Match, child => child.team2)
  matchsAsTeam2?: Match[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
