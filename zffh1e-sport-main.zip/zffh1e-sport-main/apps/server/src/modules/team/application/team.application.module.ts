import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { TeamDomainModule } from '../domain'
import { TeamController } from './team.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { TeamBySportController } from './teamBySport.controller'

@Module({
  imports: [AuthenticationDomainModule, TeamDomainModule, SportDomainModule],
  controllers: [TeamController, TeamBySportController],
  providers: [],
})
export class TeamApplicationModule {}
