import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationSportSubscriber } from './subscribers/notification.sport.subscriber'

import { NotificationTeamSubscriber } from './subscribers/notification.team.subscriber'

import { NotificationPlayerSubscriber } from './subscribers/notification.player.subscriber'

import { NotificationMatchSubscriber } from './subscribers/notification.match.subscriber'

import { NotificationLiveScoreSubscriber } from './subscribers/notification.liveScore.subscriber'

import { NotificationNewsArticleSubscriber } from './subscribers/notification.newsArticle.subscriber'

import { NotificationHistoricalDataSubscriber } from './subscribers/notification.historicalData.subscriber'

import { NotificationInteractiveFeatureSubscriber } from './subscribers/notification.interactiveFeature.subscriber'

import { NotificationMultimediaContentSubscriber } from './subscribers/notification.multimediaContent.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationSportSubscriber,

    NotificationTeamSubscriber,

    NotificationPlayerSubscriber,

    NotificationMatchSubscriber,

    NotificationLiveScoreSubscriber,

    NotificationNewsArticleSubscriber,

    NotificationHistoricalDataSubscriber,

    NotificationInteractiveFeatureSubscriber,

    NotificationMultimediaContentSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
