import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { SportDomainModule } from '../domain'
import { SportController } from './sport.controller'

@Module({
  imports: [AuthenticationDomainModule, SportDomainModule],
  controllers: [SportController],
  providers: [],
})
export class SportApplicationModule {}
