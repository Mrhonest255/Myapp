export namespace SportApplicationEvent {
  export namespace SportCreated {
    export const key = 'sport.application.sport.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
