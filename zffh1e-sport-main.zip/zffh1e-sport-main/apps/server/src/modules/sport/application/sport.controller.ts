import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Sport, SportDomainFacade } from '@server/modules/sport/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { SportApplicationEvent } from './sport.application.event'
import { SportCreateDto, SportUpdateDto } from './sport.dto'

@Controller('/v1/sports')
export class SportController {
  constructor(
    private eventService: EventService,
    private sportDomainFacade: SportDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.sportDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: SportCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.sportDomainFacade.create(body)

    await this.eventService.emit<SportApplicationEvent.SportCreated.Payload>(
      SportApplicationEvent.SportCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:sportId')
  async findOne(@Param('sportId') sportId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.sportDomainFacade.findOneByIdOrFail(
      sportId,
      queryOptions,
    )

    return item
  }

  @Patch('/:sportId')
  async update(
    @Param('sportId') sportId: string,
    @Body() body: SportUpdateDto,
  ) {
    const item = await this.sportDomainFacade.findOneByIdOrFail(sportId)

    const itemUpdated = await this.sportDomainFacade.update(
      item,
      body as Partial<Sport>,
    )
    return itemUpdated
  }

  @Delete('/:sportId')
  async delete(@Param('sportId') sportId: string) {
    const item = await this.sportDomainFacade.findOneByIdOrFail(sportId)

    await this.sportDomainFacade.delete(item)

    return item
  }
}
