import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Team } from '../../../modules/team/domain'

import { Match } from '../../../modules/match/domain'

import { LiveScore } from '../../../modules/liveScore/domain'

import { NewsArticle } from '../../../modules/newsArticle/domain'

import { InteractiveFeature } from '../../../modules/interactiveFeature/domain'

import { MultimediaContent } from '../../../modules/multimediaContent/domain'

@Entity()
export class Sport {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  name?: string

  @OneToMany(() => Team, child => child.sport)
  teams?: Team[]

  @OneToMany(() => Match, child => child.sport)
  matchs?: Match[]

  @OneToMany(() => LiveScore, child => child.sport)
  liveScores?: LiveScore[]

  @OneToMany(() => NewsArticle, child => child.sport)
  newsArticles?: NewsArticle[]

  @OneToMany(() => InteractiveFeature, child => child.sport)
  interactiveFeatures?: InteractiveFeature[]

  @OneToMany(() => MultimediaContent, child => child.sport)
  multimediaContents?: MultimediaContent[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
