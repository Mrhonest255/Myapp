import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { SportDomainFacade } from './sport.domain.facade'
import { Sport } from './sport.model'

@Module({
  imports: [TypeOrmModule.forFeature([Sport]), DatabaseHelperModule],
  providers: [SportDomainFacade, SportDomainFacade],
  exports: [SportDomainFacade],
})
export class SportDomainModule {}
