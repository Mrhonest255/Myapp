import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Team } from '../../../modules/team/domain'

@Entity()
export class Player {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  name?: string

  @Column({ nullable: true })
  biography?: string

  @Column({ nullable: true })
  statistics?: string

  @Column({ nullable: true })
  teamId?: string

  @ManyToOne(() => Team, parent => parent.players)
  @JoinColumn({ name: 'teamId' })
  team?: Team

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
