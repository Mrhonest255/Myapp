import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { PlayerDomainModule } from '../domain'
import { PlayerController } from './player.controller'

import { TeamDomainModule } from '../../../modules/team/domain'

import { PlayerByTeamController } from './playerByTeam.controller'

@Module({
  imports: [AuthenticationDomainModule, PlayerDomainModule, TeamDomainModule],
  controllers: [PlayerController, PlayerByTeamController],
  providers: [],
})
export class PlayerApplicationModule {}
