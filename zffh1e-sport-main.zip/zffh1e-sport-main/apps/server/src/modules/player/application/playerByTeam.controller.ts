import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { PlayerDomainFacade } from '@server/modules/player/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { PlayerApplicationEvent } from './player.application.event'
import { PlayerCreateDto } from './player.dto'

import { TeamDomainFacade } from '../../team/domain'

@Controller('/v1/teams')
export class PlayerByTeamController {
  constructor(
    private teamDomainFacade: TeamDomainFacade,

    private playerDomainFacade: PlayerDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/team/:teamId/players')
  async findManyTeamId(
    @Param('teamId') teamId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.teamDomainFacade.findOneByIdOrFail(teamId)

    const items = await this.playerDomainFacade.findManyByTeam(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/team/:teamId/players')
  async createByTeamId(
    @Param('teamId') teamId: string,
    @Body() body: PlayerCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, teamId }

    const item = await this.playerDomainFacade.create(valuesUpdated)

    await this.eventService.emit<PlayerApplicationEvent.PlayerCreated.Payload>(
      PlayerApplicationEvent.PlayerCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
