import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { SportApplicationModule } from './sport/application'

import { TeamApplicationModule } from './team/application'

import { PlayerApplicationModule } from './player/application'

import { MatchApplicationModule } from './match/application'

import { LiveScoreApplicationModule } from './liveScore/application'

import { NewsArticleApplicationModule } from './newsArticle/application'

import { HistoricalDataApplicationModule } from './historicalData/application'

import { InteractiveFeatureApplicationModule } from './interactiveFeature/application'

import { MultimediaContentApplicationModule } from './multimediaContent/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { BillingApplicationModule } from './billing/application'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,
    BillingApplicationModule,

    SportApplicationModule,

    TeamApplicationModule,

    PlayerApplicationModule,

    MatchApplicationModule,

    LiveScoreApplicationModule,

    NewsArticleApplicationModule,

    HistoricalDataApplicationModule,

    InteractiveFeatureApplicationModule,

    MultimediaContentApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
