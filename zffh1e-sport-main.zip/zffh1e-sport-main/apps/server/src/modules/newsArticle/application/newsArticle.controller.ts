import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  NewsArticle,
  NewsArticleDomainFacade,
} from '@server/modules/newsArticle/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { NewsArticleApplicationEvent } from './newsArticle.application.event'
import { NewsArticleCreateDto, NewsArticleUpdateDto } from './newsArticle.dto'

@Controller('/v1/newsArticles')
export class NewsArticleController {
  constructor(
    private eventService: EventService,
    private newsArticleDomainFacade: NewsArticleDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.newsArticleDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: NewsArticleCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.newsArticleDomainFacade.create(body)

    await this.eventService.emit<NewsArticleApplicationEvent.NewsArticleCreated.Payload>(
      NewsArticleApplicationEvent.NewsArticleCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:newsArticleId')
  async findOne(
    @Param('newsArticleId') newsArticleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.newsArticleDomainFacade.findOneByIdOrFail(
      newsArticleId,
      queryOptions,
    )

    return item
  }

  @Patch('/:newsArticleId')
  async update(
    @Param('newsArticleId') newsArticleId: string,
    @Body() body: NewsArticleUpdateDto,
  ) {
    const item =
      await this.newsArticleDomainFacade.findOneByIdOrFail(newsArticleId)

    const itemUpdated = await this.newsArticleDomainFacade.update(
      item,
      body as Partial<NewsArticle>,
    )
    return itemUpdated
  }

  @Delete('/:newsArticleId')
  async delete(@Param('newsArticleId') newsArticleId: string) {
    const item =
      await this.newsArticleDomainFacade.findOneByIdOrFail(newsArticleId)

    await this.newsArticleDomainFacade.delete(item)

    return item
  }
}
