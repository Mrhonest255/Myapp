import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { NewsArticleDomainModule } from '../domain'
import { NewsArticleController } from './newsArticle.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { NewsArticleBySportController } from './newsArticleBySport.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    NewsArticleDomainModule,

    SportDomainModule,
  ],
  controllers: [NewsArticleController, NewsArticleBySportController],
  providers: [],
})
export class NewsArticleApplicationModule {}
