export namespace NewsArticleApplicationEvent {
  export namespace NewsArticleCreated {
    export const key = 'newsArticle.application.newsArticle.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
