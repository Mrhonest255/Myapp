import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { NewsArticleDomainFacade } from '@server/modules/newsArticle/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { NewsArticleApplicationEvent } from './newsArticle.application.event'
import { NewsArticleCreateDto } from './newsArticle.dto'

import { SportDomainFacade } from '../../sport/domain'

@Controller('/v1/sports')
export class NewsArticleBySportController {
  constructor(
    private sportDomainFacade: SportDomainFacade,

    private newsArticleDomainFacade: NewsArticleDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/sport/:sportId/newsArticles')
  async findManySportId(
    @Param('sportId') sportId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.sportDomainFacade.findOneByIdOrFail(sportId)

    const items = await this.newsArticleDomainFacade.findManyBySport(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/sport/:sportId/newsArticles')
  async createBySportId(
    @Param('sportId') sportId: string,
    @Body() body: NewsArticleCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, sportId }

    const item = await this.newsArticleDomainFacade.create(valuesUpdated)

    await this.eventService.emit<NewsArticleApplicationEvent.NewsArticleCreated.Payload>(
      NewsArticleApplicationEvent.NewsArticleCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
