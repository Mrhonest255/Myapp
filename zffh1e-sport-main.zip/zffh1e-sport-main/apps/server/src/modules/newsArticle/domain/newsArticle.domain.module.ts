import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { NewsArticleDomainFacade } from './newsArticle.domain.facade'
import { NewsArticle } from './newsArticle.model'

@Module({
  imports: [TypeOrmModule.forFeature([NewsArticle]), DatabaseHelperModule],
  providers: [NewsArticleDomainFacade, NewsArticleDomainFacade],
  exports: [NewsArticleDomainFacade],
})
export class NewsArticleDomainModule {}
