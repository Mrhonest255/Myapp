import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { NewsArticle } from './newsArticle.model'

import { Sport } from '../../sport/domain'

@Injectable()
export class NewsArticleDomainFacade {
  constructor(
    @InjectRepository(NewsArticle)
    private repository: Repository<NewsArticle>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<NewsArticle>): Promise<NewsArticle> {
    return this.repository.save(values)
  }

  async update(
    item: NewsArticle,
    values: Partial<NewsArticle>,
  ): Promise<NewsArticle> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: NewsArticle): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<NewsArticle> = {},
  ): Promise<NewsArticle[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<NewsArticle> = {},
  ): Promise<NewsArticle> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyBySport(
    item: Sport,
    queryOptions: RequestHelper.QueryOptions<NewsArticle> = {},
  ): Promise<NewsArticle[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('sport')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sportId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
