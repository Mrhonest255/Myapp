import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class HistoricalDataCreateDto {
  @IsString()
  @IsOptional()
  score?: string

  @IsString()
  @IsOptional()
  performanceStatistics?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class HistoricalDataUpdateDto {
  @IsString()
  @IsOptional()
  score?: string

  @IsString()
  @IsOptional()
  performanceStatistics?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
