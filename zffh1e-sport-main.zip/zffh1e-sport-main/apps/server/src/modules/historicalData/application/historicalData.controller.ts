import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  HistoricalData,
  HistoricalDataDomainFacade,
} from '@server/modules/historicalData/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { HistoricalDataApplicationEvent } from './historicalData.application.event'
import {
  HistoricalDataCreateDto,
  HistoricalDataUpdateDto,
} from './historicalData.dto'

@Controller('/v1/historicalDatas')
export class HistoricalDataController {
  constructor(
    private eventService: EventService,
    private historicalDataDomainFacade: HistoricalDataDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.historicalDataDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: HistoricalDataCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.historicalDataDomainFacade.create(body)

    await this.eventService.emit<HistoricalDataApplicationEvent.HistoricalDataCreated.Payload>(
      HistoricalDataApplicationEvent.HistoricalDataCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:historicalDataId')
  async findOne(
    @Param('historicalDataId') historicalDataId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.historicalDataDomainFacade.findOneByIdOrFail(
      historicalDataId,
      queryOptions,
    )

    return item
  }

  @Patch('/:historicalDataId')
  async update(
    @Param('historicalDataId') historicalDataId: string,
    @Body() body: HistoricalDataUpdateDto,
  ) {
    const item =
      await this.historicalDataDomainFacade.findOneByIdOrFail(historicalDataId)

    const itemUpdated = await this.historicalDataDomainFacade.update(
      item,
      body as Partial<HistoricalData>,
    )
    return itemUpdated
  }

  @Delete('/:historicalDataId')
  async delete(@Param('historicalDataId') historicalDataId: string) {
    const item =
      await this.historicalDataDomainFacade.findOneByIdOrFail(historicalDataId)

    await this.historicalDataDomainFacade.delete(item)

    return item
  }
}
