import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { HistoricalDataDomainFacade } from '@server/modules/historicalData/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { HistoricalDataApplicationEvent } from './historicalData.application.event'
import { HistoricalDataCreateDto } from './historicalData.dto'

import { MatchDomainFacade } from '../../match/domain'

@Controller('/v1/matchs')
export class HistoricalDataByMatchController {
  constructor(
    private matchDomainFacade: MatchDomainFacade,

    private historicalDataDomainFacade: HistoricalDataDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/match/:matchId/historicalDatas')
  async findManyMatchId(
    @Param('matchId') matchId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.matchDomainFacade.findOneByIdOrFail(matchId)

    const items = await this.historicalDataDomainFacade.findManyByMatch(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/match/:matchId/historicalDatas')
  async createByMatchId(
    @Param('matchId') matchId: string,
    @Body() body: HistoricalDataCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, matchId }

    const item = await this.historicalDataDomainFacade.create(valuesUpdated)

    await this.eventService.emit<HistoricalDataApplicationEvent.HistoricalDataCreated.Payload>(
      HistoricalDataApplicationEvent.HistoricalDataCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
