import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { HistoricalDataDomainModule } from '../domain'
import { HistoricalDataController } from './historicalData.controller'

import { MatchDomainModule } from '../../../modules/match/domain'

import { HistoricalDataByMatchController } from './historicalDataByMatch.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    HistoricalDataDomainModule,

    MatchDomainModule,
  ],
  controllers: [HistoricalDataController, HistoricalDataByMatchController],
  providers: [],
})
export class HistoricalDataApplicationModule {}
