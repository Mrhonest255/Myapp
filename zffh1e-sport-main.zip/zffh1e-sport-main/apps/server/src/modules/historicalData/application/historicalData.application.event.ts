export namespace HistoricalDataApplicationEvent {
  export namespace HistoricalDataCreated {
    export const key = 'historicalData.application.historicalData.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
