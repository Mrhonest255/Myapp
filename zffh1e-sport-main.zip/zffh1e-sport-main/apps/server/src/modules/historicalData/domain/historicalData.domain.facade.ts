import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { HistoricalData } from './historicalData.model'

import { Match } from '../../match/domain'

@Injectable()
export class HistoricalDataDomainFacade {
  constructor(
    @InjectRepository(HistoricalData)
    private repository: Repository<HistoricalData>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<HistoricalData>): Promise<HistoricalData> {
    return this.repository.save(values)
  }

  async update(
    item: HistoricalData,
    values: Partial<HistoricalData>,
  ): Promise<HistoricalData> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: HistoricalData): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<HistoricalData> = {},
  ): Promise<HistoricalData[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<HistoricalData> = {},
  ): Promise<HistoricalData> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByMatch(
    item: Match,
    queryOptions: RequestHelper.QueryOptions<HistoricalData> = {},
  ): Promise<HistoricalData[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('match')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        matchId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
