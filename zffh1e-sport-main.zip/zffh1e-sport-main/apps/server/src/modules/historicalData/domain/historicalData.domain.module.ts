import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { HistoricalDataDomainFacade } from './historicalData.domain.facade'
import { HistoricalData } from './historicalData.model'

@Module({
  imports: [TypeOrmModule.forFeature([HistoricalData]), DatabaseHelperModule],
  providers: [HistoricalDataDomainFacade, HistoricalDataDomainFacade],
  exports: [HistoricalDataDomainFacade],
})
export class HistoricalDataDomainModule {}
