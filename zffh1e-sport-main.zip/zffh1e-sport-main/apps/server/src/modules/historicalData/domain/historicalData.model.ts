import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Match } from '../../../modules/match/domain'

@Entity()
export class HistoricalData {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  score?: string

  @Column({ nullable: true })
  performanceStatistics?: string

  @Column({ nullable: true })
  matchId?: string

  @ManyToOne(() => Match, parent => parent.historicalDatas)
  @JoinColumn({ name: 'matchId' })
  match?: Match

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
