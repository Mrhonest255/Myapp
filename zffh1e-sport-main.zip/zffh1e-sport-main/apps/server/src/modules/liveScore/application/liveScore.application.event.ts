export namespace LiveScoreApplicationEvent {
  export namespace LiveScoreCreated {
    export const key = 'liveScore.application.liveScore.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
