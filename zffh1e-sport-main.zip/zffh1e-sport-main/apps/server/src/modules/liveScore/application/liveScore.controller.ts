import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  LiveScore,
  LiveScoreDomainFacade,
} from '@server/modules/liveScore/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { LiveScoreApplicationEvent } from './liveScore.application.event'
import { LiveScoreCreateDto, LiveScoreUpdateDto } from './liveScore.dto'

@Controller('/v1/liveScores')
export class LiveScoreController {
  constructor(
    private eventService: EventService,
    private liveScoreDomainFacade: LiveScoreDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.liveScoreDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: LiveScoreCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.liveScoreDomainFacade.create(body)

    await this.eventService.emit<LiveScoreApplicationEvent.LiveScoreCreated.Payload>(
      LiveScoreApplicationEvent.LiveScoreCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:liveScoreId')
  async findOne(
    @Param('liveScoreId') liveScoreId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.liveScoreDomainFacade.findOneByIdOrFail(
      liveScoreId,
      queryOptions,
    )

    return item
  }

  @Patch('/:liveScoreId')
  async update(
    @Param('liveScoreId') liveScoreId: string,
    @Body() body: LiveScoreUpdateDto,
  ) {
    const item = await this.liveScoreDomainFacade.findOneByIdOrFail(liveScoreId)

    const itemUpdated = await this.liveScoreDomainFacade.update(
      item,
      body as Partial<LiveScore>,
    )
    return itemUpdated
  }

  @Delete('/:liveScoreId')
  async delete(@Param('liveScoreId') liveScoreId: string) {
    const item = await this.liveScoreDomainFacade.findOneByIdOrFail(liveScoreId)

    await this.liveScoreDomainFacade.delete(item)

    return item
  }
}
