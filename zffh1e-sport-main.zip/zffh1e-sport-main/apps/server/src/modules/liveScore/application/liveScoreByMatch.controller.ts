import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { LiveScoreDomainFacade } from '@server/modules/liveScore/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { LiveScoreApplicationEvent } from './liveScore.application.event'
import { LiveScoreCreateDto } from './liveScore.dto'

import { MatchDomainFacade } from '../../match/domain'

@Controller('/v1/matchs')
export class LiveScoreByMatchController {
  constructor(
    private matchDomainFacade: MatchDomainFacade,

    private liveScoreDomainFacade: LiveScoreDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/match/:matchId/liveScores')
  async findManyMatchId(
    @Param('matchId') matchId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.matchDomainFacade.findOneByIdOrFail(matchId)

    const items = await this.liveScoreDomainFacade.findManyByMatch(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/match/:matchId/liveScores')
  async createByMatchId(
    @Param('matchId') matchId: string,
    @Body() body: LiveScoreCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, matchId }

    const item = await this.liveScoreDomainFacade.create(valuesUpdated)

    await this.eventService.emit<LiveScoreApplicationEvent.LiveScoreCreated.Payload>(
      LiveScoreApplicationEvent.LiveScoreCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
