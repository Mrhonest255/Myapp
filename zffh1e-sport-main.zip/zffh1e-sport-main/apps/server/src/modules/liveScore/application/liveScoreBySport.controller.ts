import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { LiveScoreDomainFacade } from '@server/modules/liveScore/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { LiveScoreApplicationEvent } from './liveScore.application.event'
import { LiveScoreCreateDto } from './liveScore.dto'

import { SportDomainFacade } from '../../sport/domain'

@Controller('/v1/sports')
export class LiveScoreBySportController {
  constructor(
    private sportDomainFacade: SportDomainFacade,

    private liveScoreDomainFacade: LiveScoreDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/sport/:sportId/liveScores')
  async findManySportId(
    @Param('sportId') sportId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.sportDomainFacade.findOneByIdOrFail(sportId)

    const items = await this.liveScoreDomainFacade.findManyBySport(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/sport/:sportId/liveScores')
  async createBySportId(
    @Param('sportId') sportId: string,
    @Body() body: LiveScoreCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, sportId }

    const item = await this.liveScoreDomainFacade.create(valuesUpdated)

    await this.eventService.emit<LiveScoreApplicationEvent.LiveScoreCreated.Payload>(
      LiveScoreApplicationEvent.LiveScoreCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
