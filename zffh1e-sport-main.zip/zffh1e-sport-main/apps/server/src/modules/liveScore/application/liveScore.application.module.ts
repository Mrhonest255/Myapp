import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { LiveScoreDomainModule } from '../domain'
import { LiveScoreController } from './liveScore.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { LiveScoreBySportController } from './liveScoreBySport.controller'

import { MatchDomainModule } from '../../../modules/match/domain'

import { LiveScoreByMatchController } from './liveScoreByMatch.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    LiveScoreDomainModule,

    SportDomainModule,

    MatchDomainModule,
  ],
  controllers: [
    LiveScoreController,

    LiveScoreBySportController,

    LiveScoreByMatchController,
  ],
  providers: [],
})
export class LiveScoreApplicationModule {}
