import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class LiveScoreCreateDto {
  @IsString()
  @IsOptional()
  score?: string

  @IsString()
  @IsOptional()
  updateTime?: string

  @IsString()
  @IsOptional()
  sportId?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class LiveScoreUpdateDto {
  @IsString()
  @IsOptional()
  score?: string

  @IsString()
  @IsOptional()
  updateTime?: string

  @IsString()
  @IsOptional()
  sportId?: string

  @IsString()
  @IsOptional()
  matchId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
