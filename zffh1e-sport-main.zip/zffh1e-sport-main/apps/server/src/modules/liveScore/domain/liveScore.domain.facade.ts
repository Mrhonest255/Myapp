import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { LiveScore } from './liveScore.model'

import { Sport } from '../../sport/domain'

import { Match } from '../../match/domain'

@Injectable()
export class LiveScoreDomainFacade {
  constructor(
    @InjectRepository(LiveScore)
    private repository: Repository<LiveScore>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<LiveScore>): Promise<LiveScore> {
    return this.repository.save(values)
  }

  async update(
    item: LiveScore,
    values: Partial<LiveScore>,
  ): Promise<LiveScore> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: LiveScore): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<LiveScore> = {},
  ): Promise<LiveScore[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<LiveScore> = {},
  ): Promise<LiveScore> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyBySport(
    item: Sport,
    queryOptions: RequestHelper.QueryOptions<LiveScore> = {},
  ): Promise<LiveScore[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('sport')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sportId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByMatch(
    item: Match,
    queryOptions: RequestHelper.QueryOptions<LiveScore> = {},
  ): Promise<LiveScore[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('match')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        matchId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
