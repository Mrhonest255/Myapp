import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { LiveScoreDomainFacade } from './liveScore.domain.facade'
import { LiveScore } from './liveScore.model'

@Module({
  imports: [TypeOrmModule.forFeature([LiveScore]), DatabaseHelperModule],
  providers: [LiveScoreDomainFacade, LiveScoreDomainFacade],
  exports: [LiveScoreDomainFacade],
})
export class LiveScoreDomainModule {}
