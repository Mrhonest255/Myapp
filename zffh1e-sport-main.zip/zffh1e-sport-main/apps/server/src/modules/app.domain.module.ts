import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { SportDomainModule } from './sport/domain'

import { TeamDomainModule } from './team/domain'

import { PlayerDomainModule } from './player/domain'

import { MatchDomainModule } from './match/domain'

import { LiveScoreDomainModule } from './liveScore/domain'

import { NewsArticleDomainModule } from './newsArticle/domain'

import { HistoricalDataDomainModule } from './historicalData/domain'

import { InteractiveFeatureDomainModule } from './interactiveFeature/domain'

import { MultimediaContentDomainModule } from './multimediaContent/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    SportDomainModule,

    TeamDomainModule,

    PlayerDomainModule,

    MatchDomainModule,

    LiveScoreDomainModule,

    NewsArticleDomainModule,

    HistoricalDataDomainModule,

    InteractiveFeatureDomainModule,

    MultimediaContentDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
