import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Sport } from '../../../modules/sport/domain'

@Entity()
export class InteractiveFeature {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  type?: string

  @Column({ nullable: true })
  content?: string

  @Column({ nullable: true })
  sportId?: string

  @ManyToOne(() => Sport, parent => parent.interactiveFeatures)
  @JoinColumn({ name: 'sportId' })
  sport?: Sport

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
