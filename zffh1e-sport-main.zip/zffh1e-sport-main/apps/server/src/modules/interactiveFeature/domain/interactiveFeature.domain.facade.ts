import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { InteractiveFeature } from './interactiveFeature.model'

import { Sport } from '../../sport/domain'

@Injectable()
export class InteractiveFeatureDomainFacade {
  constructor(
    @InjectRepository(InteractiveFeature)
    private repository: Repository<InteractiveFeature>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    return this.repository.save(values)
  }

  async update(
    item: InteractiveFeature,
    values: Partial<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: InteractiveFeature): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<InteractiveFeature> = {},
  ): Promise<InteractiveFeature[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<InteractiveFeature> = {},
  ): Promise<InteractiveFeature> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyBySport(
    item: Sport,
    queryOptions: RequestHelper.QueryOptions<InteractiveFeature> = {},
  ): Promise<InteractiveFeature[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('sport')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        sportId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
