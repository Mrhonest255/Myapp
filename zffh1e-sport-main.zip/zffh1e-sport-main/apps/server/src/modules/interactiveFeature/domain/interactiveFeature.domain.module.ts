import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { InteractiveFeatureDomainFacade } from './interactiveFeature.domain.facade'
import { InteractiveFeature } from './interactiveFeature.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([InteractiveFeature]),
    DatabaseHelperModule,
  ],
  providers: [InteractiveFeatureDomainFacade, InteractiveFeatureDomainFacade],
  exports: [InteractiveFeatureDomainFacade],
})
export class InteractiveFeatureDomainModule {}
