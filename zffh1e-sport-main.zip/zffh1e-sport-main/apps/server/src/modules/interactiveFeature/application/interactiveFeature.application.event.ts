export namespace InteractiveFeatureApplicationEvent {
  export namespace InteractiveFeatureCreated {
    export const key =
      'interactiveFeature.application.interactiveFeature.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
