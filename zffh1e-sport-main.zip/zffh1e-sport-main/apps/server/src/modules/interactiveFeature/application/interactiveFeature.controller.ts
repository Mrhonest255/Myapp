import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  InteractiveFeature,
  InteractiveFeatureDomainFacade,
} from '@server/modules/interactiveFeature/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { InteractiveFeatureApplicationEvent } from './interactiveFeature.application.event'
import {
  InteractiveFeatureCreateDto,
  InteractiveFeatureUpdateDto,
} from './interactiveFeature.dto'

@Controller('/v1/interactiveFeatures')
export class InteractiveFeatureController {
  constructor(
    private eventService: EventService,
    private interactiveFeatureDomainFacade: InteractiveFeatureDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items =
      await this.interactiveFeatureDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: InteractiveFeatureCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.interactiveFeatureDomainFacade.create(body)

    await this.eventService.emit<InteractiveFeatureApplicationEvent.InteractiveFeatureCreated.Payload>(
      InteractiveFeatureApplicationEvent.InteractiveFeatureCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:interactiveFeatureId')
  async findOne(
    @Param('interactiveFeatureId') interactiveFeatureId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.interactiveFeatureDomainFacade.findOneByIdOrFail(
      interactiveFeatureId,
      queryOptions,
    )

    return item
  }

  @Patch('/:interactiveFeatureId')
  async update(
    @Param('interactiveFeatureId') interactiveFeatureId: string,
    @Body() body: InteractiveFeatureUpdateDto,
  ) {
    const item =
      await this.interactiveFeatureDomainFacade.findOneByIdOrFail(
        interactiveFeatureId,
      )

    const itemUpdated = await this.interactiveFeatureDomainFacade.update(
      item,
      body as Partial<InteractiveFeature>,
    )
    return itemUpdated
  }

  @Delete('/:interactiveFeatureId')
  async delete(@Param('interactiveFeatureId') interactiveFeatureId: string) {
    const item =
      await this.interactiveFeatureDomainFacade.findOneByIdOrFail(
        interactiveFeatureId,
      )

    await this.interactiveFeatureDomainFacade.delete(item)

    return item
  }
}
