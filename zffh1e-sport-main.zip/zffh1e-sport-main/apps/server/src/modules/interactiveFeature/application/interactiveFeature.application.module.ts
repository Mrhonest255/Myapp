import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { InteractiveFeatureDomainModule } from '../domain'
import { InteractiveFeatureController } from './interactiveFeature.controller'

import { SportDomainModule } from '../../../modules/sport/domain'

import { InteractiveFeatureBySportController } from './interactiveFeatureBySport.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    InteractiveFeatureDomainModule,

    SportDomainModule,
  ],
  controllers: [
    InteractiveFeatureController,

    InteractiveFeatureBySportController,
  ],
  providers: [],
})
export class InteractiveFeatureApplicationModule {}
