'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Spin } from 'antd'
import { CalendarOutlined, EnvironmentOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function MatchSchedulesPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [matches, setMatches] = useState<Model.Match[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const fetchMatches = async () => {
      try {
        const matchesFound = await Api.Match.findMany({
          includes: ['sport', 'team1', 'team2'],
        })
        setMatches(matchesFound)
      } catch (error) {
        enqueueSnackbar('Failed to load match schedules', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchMatches()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Upcoming Match Schedules</Title>
      <Text>
        Check out the upcoming match schedules for different sports and plan to
        watch or attend the games.
      </Text>
      {loading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
          {matches?.map(match => (
            <Col xs={24} sm={12} md={8} lg={6} key={match.id}>
              <Card
                title={`${match.team1?.name} vs ${match.team2?.name}`}
                bordered={false}
              >
                <p>
                  <CalendarOutlined />{' '}
                  {dayjs(match.scheduleTime).format('MMMM D, YYYY h:mm A')}
                </p>
                <p>
                  <EnvironmentOutlined /> {match.location}
                </p>
                <p>Sport: {match.sport?.name}</p>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
