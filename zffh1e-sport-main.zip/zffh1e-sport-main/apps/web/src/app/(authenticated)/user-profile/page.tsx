'use client'

import { useEffect, useState } from 'react'
import { Form, Input, Button, Select, Row, Col, Typography, Spin } from 'antd'
import { TeamOutlined, UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UserProfilePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [user, setUser] = useState<Model.User | null>(null)
  const [teams, setTeams] = useState<Model.Team[]>([])
  const [players, setPlayers] = useState<Model.Player[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    if (userId) {
      fetchUserData()
      fetchTeams()
      fetchPlayers()
    }
  }, [userId])

  const fetchUserData = async () => {
    try {
      const userFound = await Api.User.findOne(userId, {
        includes: ['notifications'],
      })
      setUser(userFound)
      setLoading(false)
    } catch (error) {
      enqueueSnackbar('Failed to fetch user data', { variant: 'error' })
      setLoading(false)
    }
  }

  const fetchTeams = async () => {
    try {
      const teamsFound = await Api.Team.findMany({ includes: ['sport'] })
      setTeams(teamsFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch teams', { variant: 'error' })
    }
  }

  const fetchPlayers = async () => {
    try {
      const playersFound = await Api.Player.findMany({ includes: ['team'] })
      setPlayers(playersFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch players', { variant: 'error' })
    }
  }

  const handleUpdateProfile = async (values: any) => {
    try {
      const updatedUser = await Api.User.updateOne(userId, values)
      setUser(updatedUser)
      enqueueSnackbar('Profile updated successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to update profile', { variant: 'error' })
    }
  }

  if (loading) {
    return (
      <PageLayout layout="narrow">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>User Profile</Title>
      <Text>Customize your profile and preferences</Text>
      <Form
        layout="vertical"
        initialValues={user}
        onFinish={handleUpdateProfile}
      >
        <Form.Item
          label="Name"
          name="name"
          rules={[{ required: true, message: 'Please input your name!' }]}
        >
          <Input prefix={<UserOutlined />} />
        </Form.Item>
        <Form.Item
          label="Email"
          name="email"
          rules={[{ required: true, message: 'Please input your email!' }]}
        >
          <Input type="email" />
        </Form.Item>
        <Form.Item label="Favorite Teams" name="favoriteTeams">
          <Select mode="multiple" placeholder="Select your favorite teams">
            {teams.map(team => (
              <Option key={team.id} value={team.id}>
                {team.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item label="Favorite Players" name="favoritePlayers">
          <Select mode="multiple" placeholder="Select your favorite players">
            {players.map(player => (
              <Option key={player.id} value={player.id}>
                {player.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save Profile
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
