'use client'

import { useEffect, useState } from 'react'
import { Select, Row, Col, Card, Typography, Spin } from 'antd'
import { TrophyOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [sports, setSports] = useState<Model.Sport[]>([])
  const [selectedSportId, setSelectedSportId] = useState<string | undefined>()
  const [liveScores, setLiveScores] = useState<Model.LiveScore[]>([])
  const [loading, setLoading] = useState<boolean>(false)

  useEffect(() => {
    const fetchSports = async () => {
      try {
        const sportsFound = await Api.Sport.findMany()
        setSports(sportsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch sports', { variant: 'error' })
      }
    }

    fetchSports()
  }, [])

  useEffect(() => {
    if (selectedSportId) {
      const fetchLiveScores = async () => {
        setLoading(true)
        try {
          const liveScoresFound = await Api.LiveScore.findManyBySportId(
            selectedSportId,
            { includes: ['sport', 'match'] },
          )
          setLiveScores(liveScoresFound)
        } catch (error) {
          enqueueSnackbar('Failed to fetch live scores', { variant: 'error' })
        } finally {
          setLoading(false)
        }
      }

      fetchLiveScores()
    }
  }, [selectedSportId])

  const handleSportChange = (value: string) => {
    setSelectedSportId(value)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Live Sports Scores</Title>
      <Text>Select a sport to view live scores and updates</Text>
      <Row justify="center" style={{ marginTop: 20 }}>
        <Col span={24}>
          <Select
            placeholder="Select a sport"
            onChange={handleSportChange}
            style={{ width: '100%' }}
          >
            {sports.map(sport => (
              <Option key={sport.id} value={sport.id}>
                {sport.name}
              </Option>
            ))}
          </Select>
        </Col>
      </Row>
      <Row justify="center" style={{ marginTop: 20 }}>
        {loading ? (
          <Spin size="large" />
        ) : (
          liveScores.map(liveScore => (
            <Col key={liveScore.id} span={24} style={{ marginBottom: 20 }}>
              <Card title={liveScore.match?.sport?.name} bordered={false}>
                <Row>
                  <Col span={12}>
                    <Text strong>{liveScore.match?.team1?.name}</Text>
                  </Col>
                  <Col span={12}>
                    <Text strong>{liveScore.match?.team2?.name}</Text>
                  </Col>
                </Row>
                <Row>
                  <Col span={12}>
                    <Text>{liveScore.score}</Text>
                  </Col>
                  <Col span={12}>
                    <Text>{liveScore.updateTime}</Text>
                  </Col>
                </Row>
              </Card>
            </Col>
          ))
        )}
      </Row>
    </PageLayout>
  )
}
