'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Spin } from 'antd'
import { CalendarOutlined } from '@ant-design/icons'
const { Title, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function NewsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [newsArticles, setNewsArticles] = useState<Model.NewsArticle[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const fetchNewsArticles = async () => {
      try {
        const articles = await Api.NewsArticle.findMany({ includes: ['sport'] })
        setNewsArticles(articles)
      } catch (error) {
        enqueueSnackbar('Failed to fetch news articles', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchNewsArticles()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Latest Sports News</Title>
      <Paragraph>
        Stay updated with the latest sports events, players, and teams in
        Tanzania and Zanzibar.
      </Paragraph>
      {loading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]}>
          {newsArticles?.map(article => (
            <Col xs={24} sm={12} md={8} key={article.id}>
              <Card
                title={article.title}
                extra={<CalendarOutlined />}
                style={{ width: '100%' }}
              >
                <Paragraph ellipsis={{ rows: 3 }}>{article.content}</Paragraph>
                <Paragraph type="secondary">
                  Published on:{' '}
                  {dayjs(article.publishDate).format('MMMM D, YYYY')}
                </Paragraph>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
