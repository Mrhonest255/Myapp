'use client'

import { useEffect, useState } from 'react'
import { Typography, Table, Spin } from 'antd'
import { TrophyOutlined } from '@ant-design/icons'
const { Title, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HistoricalDataPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [loading, setLoading] = useState(true)
  const [historicalData, setHistoricalData] = useState<Model.HistoricalData[]>(
    [],
  )

  useEffect(() => {
    const fetchHistoricalData = async () => {
      try {
        const data = await Api.HistoricalData.findMany({
          includes: ['match', 'match.team1', 'match.team2'],
        })
        setHistoricalData(data)
      } catch (error) {
        enqueueSnackbar('Failed to fetch historical data', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchHistoricalData()
  }, [])

  const columns = [
    {
      title: 'Match',
      dataIndex: 'match',
      key: 'match',
      render: (match: Model.Match) =>
        `${match?.team1?.name} vs ${match?.team2?.name}`,
    },
    {
      title: 'Score',
      dataIndex: 'score',
      key: 'score',
    },
    {
      title: 'Performance Statistics',
      dataIndex: 'performanceStatistics',
      key: 'performanceStatistics',
    },
    {
      title: 'Date',
      dataIndex: 'dateCreated',
      key: 'dateCreated',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD'),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2} style={{ textAlign: 'center', marginBottom: '20px' }}>
        <TrophyOutlined /> Historical Data
      </Title>
      <Paragraph style={{ textAlign: 'center', marginBottom: '40px' }}>
        Access historical data of past games, scores, and performance statistics
        to reference past sports events.
      </Paragraph>
      {loading ? (
        <Spin
          tip="Loading..."
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh',
          }}
        />
      ) : (
        <Table
          dataSource={historicalData}
          columns={columns}
          rowKey="id"
          pagination={{ pageSize: 10 }}
          style={{ margin: '0 auto', maxWidth: '1000px' }}
        />
      )}
    </PageLayout>
  )
}
