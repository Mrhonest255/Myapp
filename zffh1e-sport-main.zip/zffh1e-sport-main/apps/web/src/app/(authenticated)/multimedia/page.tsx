'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Spin } from 'antd'
import { VideoCameraOutlined, PictureOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function MultimediaContentPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [loading, setLoading] = useState(true)
  const [multimediaContents, setMultimediaContents] = useState<
    Model.MultimediaContent[]
  >([])

  useEffect(() => {
    const fetchMultimediaContents = async () => {
      try {
        const contents = await Api.MultimediaContent.findMany({
          includes: ['sport', 'match.sport'],
        })
        setMultimediaContents(contents)
      } catch (error) {
        enqueueSnackbar('Failed to load multimedia contents', {
          variant: 'error',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchMultimediaContents()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Multimedia Content</Title>
      <Text>
        View photos, videos, and highlights of recent games and important
        events.
      </Text>
      {loading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
          {multimediaContents?.map(content => (
            <Col key={content.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                hoverable
                cover={
                  content.type === 'video' ? (
                    <VideoCameraOutlined
                      style={{
                        fontSize: '48px',
                        margin: '20px auto',
                        display: 'block',
                      }}
                    />
                  ) : (
                    <PictureOutlined
                      style={{
                        fontSize: '48px',
                        margin: '20px auto',
                        display: 'block',
                      }}
                    />
                  )
                }
              >
                <Card.Meta
                  title={content.description}
                  description={content.sport?.name}
                />
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
