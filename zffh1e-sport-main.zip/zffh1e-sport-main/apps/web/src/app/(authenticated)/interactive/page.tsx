'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Card, Spin } from 'antd'
import {
  CommentOutlined,
  QuestionCircleOutlined,
  BarChartOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function InteractiveFeaturesPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [interactiveFeatures, setInteractiveFeatures] = useState<
    Model.InteractiveFeature[]
  >([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchInteractiveFeatures = async () => {
      try {
        const features = await Api.InteractiveFeature.findMany({
          includes: ['sport'],
        })
        setInteractiveFeatures(features)
      } catch (error) {
        enqueueSnackbar('Failed to load interactive features', {
          variant: 'error',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchInteractiveFeatures()
  }, [])

  const handleFeatureClick = (featureId: string) => {
    router.push(`/interactive/${featureId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2} style={{ textAlign: 'center' }}>
        Interactive Features
      </Title>
      <Text
        style={{ display: 'block', textAlign: 'center', marginBottom: '20px' }}
      >
        Participate in polls, quizzes, and discussion forums to engage with
        other users about sports topics.
      </Text>
      {loading ? (
        <Spin size="large" style={{ display: 'block', margin: '0 auto' }} />
      ) : (
        <List
          grid={{ gutter: 16, column: 3 }}
          dataSource={interactiveFeatures}
          renderItem={item => (
            <List.Item>
              <Card
                hoverable
                onClick={() => handleFeatureClick(item.id)}
                title={item.type}
                cover={
                  item.type === 'poll' ? (
                    <BarChartOutlined
                      style={{
                        fontSize: '48px',
                        textAlign: 'center',
                        margin: '20px 0',
                      }}
                    />
                  ) : item.type === 'quiz' ? (
                    <QuestionCircleOutlined
                      style={{
                        fontSize: '48px',
                        textAlign: 'center',
                        margin: '20px 0',
                      }}
                    />
                  ) : (
                    <CommentOutlined
                      style={{
                        fontSize: '48px',
                        textAlign: 'center',
                        margin: '20px 0',
                      }}
                    />
                  )
                }
              >
                <Card.Meta description={item.content} />
              </Card>
            </List.Item>
          )}
        />
      )}
    </PageLayout>
  )
}
