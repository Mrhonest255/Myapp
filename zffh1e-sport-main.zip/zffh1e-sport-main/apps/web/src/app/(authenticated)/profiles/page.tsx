'use client'

import { useEffect, useState } from 'react'
import { Typography, Row, Col, Card, Spin, Avatar } from 'antd'
import { UserOutlined, TeamOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function PlayerandTeamProfilesPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [loading, setLoading] = useState(true)
  const [player, setPlayer] = useState<Model.Player | null>(null)
  const [team, setTeam] = useState<Model.Team | null>(null)

  useEffect(() => {
    const fetchPlayerAndTeam = async () => {
      try {
        const playerId = params.playerId
        const playerData = await Api.Player.findOne(playerId, {
          includes: ['team'],
        })
        setPlayer(playerData)
        if (playerData.teamId) {
          const teamData = await Api.Team.findOne(playerData.teamId, {
            includes: ['players'],
          })
          setTeam(teamData)
        }
      } catch (error) {
        enqueueSnackbar('Failed to load player or team data', {
          variant: 'error',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchPlayerAndTeam()
  }, [params.playerId])

  if (loading) {
    return (
      <PageLayout layout="narrow">
        <Spin tip="Loading..." />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Player and Team Profiles</Title>
      <Paragraph>
        View detailed profiles of players and teams, including statistics,
        achievements, and biographies.
      </Paragraph>
      {player && (
        <Card style={{ marginBottom: '20px' }}>
          <Row gutter={[16, 16]}>
            <Col span={24} style={{ textAlign: 'center' }}>
              <Avatar size={64} icon={<UserOutlined />} />
              <Title level={3}>{player.name}</Title>
            </Col>
            <Col span={24}>
              <Title level={4}>Biography</Title>
              <Paragraph>{player.biography}</Paragraph>
            </Col>
            <Col span={24}>
              <Title level={4}>Statistics</Title>
              <Paragraph>{player.statistics}</Paragraph>
            </Col>
          </Row>
        </Card>
      )}
      {team && (
        <Card>
          <Row gutter={[16, 16]}>
            <Col span={24} style={{ textAlign: 'center' }}>
              <Avatar size={64} icon={<TeamOutlined />} />
              <Title level={3}>{team.name}</Title>
            </Col>
            <Col span={24}>
              <Title level={4}>Achievements</Title>
              <Paragraph>{team.achievements}</Paragraph>
            </Col>
            <Col span={24}>
              <Title level={4}>Players</Title>
              <Row gutter={[16, 16]}>
                {team.players?.map(player => (
                  <Col key={player.id} span={12}>
                    <Card>
                      <Title level={5}>{player.name}</Title>
                      <Paragraph>{player.biography}</Paragraph>
                    </Card>
                  </Col>
                ))}
              </Row>
            </Col>
          </Row>
        </Card>
      )}
    </PageLayout>
  )
}
