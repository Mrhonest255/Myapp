'use client'

import { useState } from 'react'
import { Button, Row, Col, Typography, Input, Space } from 'antd'
import {
  TwitterOutlined,
  FacebookOutlined,
  LinkedinOutlined,
} from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
const { TextArea } = Input
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function SocialMediaIntegrationPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [content, setContent] = useState('')

  const handleShare = async (platform: string) => {
    if (!content) {
      enqueueSnackbar('Please enter some content to share.', {
        variant: 'error',
      })
      return
    }

    try {
      // Assuming there's an API endpoint to handle social media sharing
      await Api.Notification.create({
        title: `Shared on ${platform}`,
        message: content,
        userId: userId,
        dateCreated: new Date().toISOString(),
        dateUpdated: new Date().toISOString(),
        dateDeleted: '',
      })
      enqueueSnackbar(`Content shared on ${platform} successfully!`, {
        variant: 'success',
      })
    } catch (error) {
      enqueueSnackbar(`Failed to share on ${platform}. Please try again.`, {
        variant: 'error',
      })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center" align="middle" style={{ minHeight: '100vh' }}>
        <Col span={24}>
          <Title level={2}>Share Sports Updates</Title>
          <Paragraph>
            As a user, you can share updates and content on popular social media
            platforms to engage with your social network about sports.
          </Paragraph>
          <Space direction="vertical" style={{ width: '100%' }}>
            <TextArea
              rows={4}
              placeholder="Write your sports update here..."
              value={content}
              onChange={e => setContent(e.target.value)}
            />
            <Row justify="center" gutter={16}>
              <Col>
                <Button
                  type="primary"
                  icon={<TwitterOutlined />}
                  onClick={() => handleShare('Twitter')}
                >
                  Share on Twitter
                </Button>
              </Col>
              <Col>
                <Button
                  type="primary"
                  icon={<FacebookOutlined />}
                  onClick={() => handleShare('Facebook')}
                >
                  Share on Facebook
                </Button>
              </Col>
              <Col>
                <Button
                  type="primary"
                  icon={<LinkedinOutlined />}
                  onClick={() => handleShare('LinkedIn')}
                >
                  Share on LinkedIn
                </Button>
              </Col>
            </Row>
          </Space>
        </Col>
      </Row>
    </PageLayout>
  )
}
