import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { MultimediaContent } from './multimediaContent.model'

export class MultimediaContentApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<MultimediaContent>,
  ): Promise<MultimediaContent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/multimediaContents${buildOptions}`)
  }

  static findOne(
    multimediaContentId: string,
    queryOptions?: ApiHelper.QueryOptions<MultimediaContent>,
  ): Promise<MultimediaContent> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/multimediaContents/${multimediaContentId}${buildOptions}`,
    )
  }

  static createOne(
    values: Partial<MultimediaContent>,
  ): Promise<MultimediaContent> {
    return HttpService.api.post(`/v1/multimediaContents`, values)
  }

  static updateOne(
    multimediaContentId: string,
    values: Partial<MultimediaContent>,
  ): Promise<MultimediaContent> {
    return HttpService.api.patch(
      `/v1/multimediaContents/${multimediaContentId}`,
      values,
    )
  }

  static deleteOne(multimediaContentId: string): Promise<void> {
    return HttpService.api.delete(
      `/v1/multimediaContents/${multimediaContentId}`,
    )
  }

  static findManyBySportId(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<MultimediaContent>,
  ): Promise<MultimediaContent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/sports/sport/${sportId}/multimediaContents${buildOptions}`,
    )
  }

  static createOneBySportId(
    sportId: string,
    values: Partial<MultimediaContent>,
  ): Promise<MultimediaContent> {
    return HttpService.api.post(
      `/v1/sports/sport/${sportId}/multimediaContents`,
      values,
    )
  }

  static findManyByMatchId(
    matchId: string,
    queryOptions?: ApiHelper.QueryOptions<MultimediaContent>,
  ): Promise<MultimediaContent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/matchs/match/${matchId}/multimediaContents${buildOptions}`,
    )
  }

  static createOneByMatchId(
    matchId: string,
    values: Partial<MultimediaContent>,
  ): Promise<MultimediaContent> {
    return HttpService.api.post(
      `/v1/matchs/match/${matchId}/multimediaContents`,
      values,
    )
  }
}
