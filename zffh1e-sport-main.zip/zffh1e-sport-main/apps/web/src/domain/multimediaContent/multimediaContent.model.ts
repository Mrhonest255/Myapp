import { Sport } from '../sport'

import { Match } from '../match'

export class MultimediaContent {
  id: string

  type?: string

  url?: string

  description?: string

  sportId?: string

  sport?: Sport

  matchId?: string

  match?: Match

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
