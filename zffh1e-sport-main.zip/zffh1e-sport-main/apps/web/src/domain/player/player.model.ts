import { Team } from '../team'

export class Player {
  id: string

  name?: string

  biography?: string

  statistics?: string

  teamId?: string

  team?: Team

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
