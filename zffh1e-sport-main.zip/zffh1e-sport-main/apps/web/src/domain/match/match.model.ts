import { Sport } from '../sport'

import { Team } from '../team'

import { LiveScore } from '../liveScore'

import { HistoricalData } from '../historicalData'

import { MultimediaContent } from '../multimediaContent'

export class Match {
  id: string

  scheduleTime?: string

  location?: string

  sportId?: string

  sport?: Sport

  team1Id?: string

  team1?: Team

  team2Id?: string

  team2?: Team

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  liveScores?: LiveScore[]

  historicalDatas?: HistoricalData[]

  multimediaContents?: MultimediaContent[]
}
