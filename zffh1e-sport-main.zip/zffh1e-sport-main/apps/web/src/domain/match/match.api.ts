import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Match } from './match.model'

export class MatchApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Match>,
  ): Promise<Match[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/matchs${buildOptions}`)
  }

  static findOne(
    matchId: string,
    queryOptions?: ApiHelper.QueryOptions<Match>,
  ): Promise<Match> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/matchs/${matchId}${buildOptions}`)
  }

  static createOne(values: Partial<Match>): Promise<Match> {
    return HttpService.api.post(`/v1/matchs`, values)
  }

  static updateOne(matchId: string, values: Partial<Match>): Promise<Match> {
    return HttpService.api.patch(`/v1/matchs/${matchId}`, values)
  }

  static deleteOne(matchId: string): Promise<void> {
    return HttpService.api.delete(`/v1/matchs/${matchId}`)
  }

  static findManyBySportId(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<Match>,
  ): Promise<Match[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/sports/sport/${sportId}/matchs${buildOptions}`,
    )
  }

  static createOneBySportId(
    sportId: string,
    values: Partial<Match>,
  ): Promise<Match> {
    return HttpService.api.post(`/v1/sports/sport/${sportId}/matchs`, values)
  }

  static findManyByTeam1Id(
    team1Id: string,
    queryOptions?: ApiHelper.QueryOptions<Match>,
  ): Promise<Match[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/teams/team1/${team1Id}/matchs${buildOptions}`,
    )
  }

  static createOneByTeam1Id(
    team1Id: string,
    values: Partial<Match>,
  ): Promise<Match> {
    return HttpService.api.post(`/v1/teams/team1/${team1Id}/matchs`, values)
  }

  static findManyByTeam2Id(
    team2Id: string,
    queryOptions?: ApiHelper.QueryOptions<Match>,
  ): Promise<Match[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/teams/team2/${team2Id}/matchs${buildOptions}`,
    )
  }

  static createOneByTeam2Id(
    team2Id: string,
    values: Partial<Match>,
  ): Promise<Match> {
    return HttpService.api.post(`/v1/teams/team2/${team2Id}/matchs`, values)
  }
}
