import { Sport } from '../sport'

import { Player } from '../player'

import { Match } from '../match'

export class Team {
  id: string

  name?: string

  achievements?: string

  sportId?: string

  sport?: Sport

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  players?: Player[]

  matchsAsTeam1?: Match[]

  matchsAsTeam2?: Match[]
}
