import { Match } from '../match'

export class HistoricalData {
  id: string

  score?: string

  performanceStatistics?: string

  matchId?: string

  match?: Match

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
