import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { HistoricalData } from './historicalData.model'

export class HistoricalDataApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<HistoricalData>,
  ): Promise<HistoricalData[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/historicalDatas${buildOptions}`)
  }

  static findOne(
    historicalDataId: string,
    queryOptions?: ApiHelper.QueryOptions<HistoricalData>,
  ): Promise<HistoricalData> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/historicalDatas/${historicalDataId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<HistoricalData>): Promise<HistoricalData> {
    return HttpService.api.post(`/v1/historicalDatas`, values)
  }

  static updateOne(
    historicalDataId: string,
    values: Partial<HistoricalData>,
  ): Promise<HistoricalData> {
    return HttpService.api.patch(
      `/v1/historicalDatas/${historicalDataId}`,
      values,
    )
  }

  static deleteOne(historicalDataId: string): Promise<void> {
    return HttpService.api.delete(`/v1/historicalDatas/${historicalDataId}`)
  }

  static findManyByMatchId(
    matchId: string,
    queryOptions?: ApiHelper.QueryOptions<HistoricalData>,
  ): Promise<HistoricalData[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/matchs/match/${matchId}/historicalDatas${buildOptions}`,
    )
  }

  static createOneByMatchId(
    matchId: string,
    values: Partial<HistoricalData>,
  ): Promise<HistoricalData> {
    return HttpService.api.post(
      `/v1/matchs/match/${matchId}/historicalDatas`,
      values,
    )
  }
}
