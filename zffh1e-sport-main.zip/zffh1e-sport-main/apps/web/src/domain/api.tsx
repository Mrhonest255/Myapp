import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { BillingApi } from './billing/billing.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { SportApi } from './sport/sport.api'

import { TeamApi } from './team/team.api'

import { PlayerApi } from './player/player.api'

import { MatchApi } from './match/match.api'

import { LiveScoreApi } from './liveScore/liveScore.api'

import { NewsArticleApi } from './newsArticle/newsArticle.api'

import { HistoricalDataApi } from './historicalData/historicalData.api'

import { InteractiveFeatureApi } from './interactiveFeature/interactiveFeature.api'

import { MultimediaContentApi } from './multimediaContent/multimediaContent.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Billing extends BillingApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Sport extends SportApi {}

  export class Team extends TeamApi {}

  export class Player extends PlayerApi {}

  export class Match extends MatchApi {}

  export class LiveScore extends LiveScoreApi {}

  export class NewsArticle extends NewsArticleApi {}

  export class HistoricalData extends HistoricalDataApi {}

  export class InteractiveFeature extends InteractiveFeatureApi {}

  export class MultimediaContent extends MultimediaContentApi {}
}
