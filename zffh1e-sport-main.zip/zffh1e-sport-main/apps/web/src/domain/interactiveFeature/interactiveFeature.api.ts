import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { InteractiveFeature } from './interactiveFeature.model'

export class InteractiveFeatureApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<InteractiveFeature>,
  ): Promise<InteractiveFeature[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/interactiveFeatures${buildOptions}`)
  }

  static findOne(
    interactiveFeatureId: string,
    queryOptions?: ApiHelper.QueryOptions<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/interactiveFeatures/${interactiveFeatureId}${buildOptions}`,
    )
  }

  static createOne(
    values: Partial<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    return HttpService.api.post(`/v1/interactiveFeatures`, values)
  }

  static updateOne(
    interactiveFeatureId: string,
    values: Partial<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    return HttpService.api.patch(
      `/v1/interactiveFeatures/${interactiveFeatureId}`,
      values,
    )
  }

  static deleteOne(interactiveFeatureId: string): Promise<void> {
    return HttpService.api.delete(
      `/v1/interactiveFeatures/${interactiveFeatureId}`,
    )
  }

  static findManyBySportId(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<InteractiveFeature>,
  ): Promise<InteractiveFeature[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/sports/sport/${sportId}/interactiveFeatures${buildOptions}`,
    )
  }

  static createOneBySportId(
    sportId: string,
    values: Partial<InteractiveFeature>,
  ): Promise<InteractiveFeature> {
    return HttpService.api.post(
      `/v1/sports/sport/${sportId}/interactiveFeatures`,
      values,
    )
  }
}
