import { Sport } from '../sport'

export class InteractiveFeature {
  id: string

  type?: string

  content?: string

  sportId?: string

  sport?: Sport

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
