import { Team } from '../team'

import { Match } from '../match'

import { LiveScore } from '../liveScore'

import { NewsArticle } from '../newsArticle'

import { InteractiveFeature } from '../interactiveFeature'

import { MultimediaContent } from '../multimediaContent'

export class Sport {
  id: string

  name?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  teams?: Team[]

  matchs?: Match[]

  liveScores?: LiveScore[]

  newsArticles?: NewsArticle[]

  interactiveFeatures?: InteractiveFeature[]

  multimediaContents?: MultimediaContent[]
}
