import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Sport } from './sport.model'

export class SportApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Sport>,
  ): Promise<Sport[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/sports${buildOptions}`)
  }

  static findOne(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<Sport>,
  ): Promise<Sport> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/sports/${sportId}${buildOptions}`)
  }

  static createOne(values: Partial<Sport>): Promise<Sport> {
    return HttpService.api.post(`/v1/sports`, values)
  }

  static updateOne(sportId: string, values: Partial<Sport>): Promise<Sport> {
    return HttpService.api.patch(`/v1/sports/${sportId}`, values)
  }

  static deleteOne(sportId: string): Promise<void> {
    return HttpService.api.delete(`/v1/sports/${sportId}`)
  }
}
