import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'
import {
  BillingPayment as BillingPaymentModel,
  BillingProduct as BillingProductModel,
  BillingSubscription as BillingSubscriptionModel,
} from './billing/billing.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Sport as SportModel } from './sport/sport.model'

import { Team as TeamModel } from './team/team.model'

import { Player as PlayerModel } from './player/player.model'

import { Match as MatchModel } from './match/match.model'

import { LiveScore as LiveScoreModel } from './liveScore/liveScore.model'

import { NewsArticle as NewsArticleModel } from './newsArticle/newsArticle.model'

import { HistoricalData as HistoricalDataModel } from './historicalData/historicalData.model'

import { InteractiveFeature as InteractiveFeatureModel } from './interactiveFeature/interactiveFeature.model'

import { MultimediaContent as MultimediaContentModel } from './multimediaContent/multimediaContent.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}
  export class BillingProduct extends BillingProductModel {}
  export class BillingPayment extends BillingPaymentModel {}
  export class BillingSubscription extends BillingSubscriptionModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Sport extends SportModel {}

  export class Team extends TeamModel {}

  export class Player extends PlayerModel {}

  export class Match extends MatchModel {}

  export class LiveScore extends LiveScoreModel {}

  export class NewsArticle extends NewsArticleModel {}

  export class HistoricalData extends HistoricalDataModel {}

  export class InteractiveFeature extends InteractiveFeatureModel {}

  export class MultimediaContent extends MultimediaContentModel {}
}
