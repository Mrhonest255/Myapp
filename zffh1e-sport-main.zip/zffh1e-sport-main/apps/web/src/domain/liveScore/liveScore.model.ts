import { Sport } from '../sport'

import { Match } from '../match'

export class LiveScore {
  id: string

  score?: string

  updateTime?: string

  sportId?: string

  sport?: Sport

  matchId?: string

  match?: Match

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
