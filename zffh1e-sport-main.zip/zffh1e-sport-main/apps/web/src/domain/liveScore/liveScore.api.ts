import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { LiveScore } from './liveScore.model'

export class LiveScoreApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<LiveScore>,
  ): Promise<LiveScore[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/liveScores${buildOptions}`)
  }

  static findOne(
    liveScoreId: string,
    queryOptions?: ApiHelper.QueryOptions<LiveScore>,
  ): Promise<LiveScore> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/liveScores/${liveScoreId}${buildOptions}`)
  }

  static createOne(values: Partial<LiveScore>): Promise<LiveScore> {
    return HttpService.api.post(`/v1/liveScores`, values)
  }

  static updateOne(
    liveScoreId: string,
    values: Partial<LiveScore>,
  ): Promise<LiveScore> {
    return HttpService.api.patch(`/v1/liveScores/${liveScoreId}`, values)
  }

  static deleteOne(liveScoreId: string): Promise<void> {
    return HttpService.api.delete(`/v1/liveScores/${liveScoreId}`)
  }

  static findManyBySportId(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<LiveScore>,
  ): Promise<LiveScore[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/sports/sport/${sportId}/liveScores${buildOptions}`,
    )
  }

  static createOneBySportId(
    sportId: string,
    values: Partial<LiveScore>,
  ): Promise<LiveScore> {
    return HttpService.api.post(
      `/v1/sports/sport/${sportId}/liveScores`,
      values,
    )
  }

  static findManyByMatchId(
    matchId: string,
    queryOptions?: ApiHelper.QueryOptions<LiveScore>,
  ): Promise<LiveScore[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/matchs/match/${matchId}/liveScores${buildOptions}`,
    )
  }

  static createOneByMatchId(
    matchId: string,
    values: Partial<LiveScore>,
  ): Promise<LiveScore> {
    return HttpService.api.post(
      `/v1/matchs/match/${matchId}/liveScores`,
      values,
    )
  }
}
