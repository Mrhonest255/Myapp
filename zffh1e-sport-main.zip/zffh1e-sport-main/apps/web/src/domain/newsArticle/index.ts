export * from './newsArticle.api'
export * from './newsArticle.model'
