import { Sport } from '../sport'

export class NewsArticle {
  id: string

  title?: string

  content?: string

  publishDate?: string

  sportId?: string

  sport?: Sport

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
