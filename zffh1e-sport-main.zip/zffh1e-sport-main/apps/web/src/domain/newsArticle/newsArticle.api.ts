import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { NewsArticle } from './newsArticle.model'

export class NewsArticleApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<NewsArticle>,
  ): Promise<NewsArticle[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/newsArticles${buildOptions}`)
  }

  static findOne(
    newsArticleId: string,
    queryOptions?: ApiHelper.QueryOptions<NewsArticle>,
  ): Promise<NewsArticle> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/newsArticles/${newsArticleId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<NewsArticle>): Promise<NewsArticle> {
    return HttpService.api.post(`/v1/newsArticles`, values)
  }

  static updateOne(
    newsArticleId: string,
    values: Partial<NewsArticle>,
  ): Promise<NewsArticle> {
    return HttpService.api.patch(`/v1/newsArticles/${newsArticleId}`, values)
  }

  static deleteOne(newsArticleId: string): Promise<void> {
    return HttpService.api.delete(`/v1/newsArticles/${newsArticleId}`)
  }

  static findManyBySportId(
    sportId: string,
    queryOptions?: ApiHelper.QueryOptions<NewsArticle>,
  ): Promise<NewsArticle[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/sports/sport/${sportId}/newsArticles${buildOptions}`,
    )
  }

  static createOneBySportId(
    sportId: string,
    values: Partial<NewsArticle>,
  ): Promise<NewsArticle> {
    return HttpService.api.post(
      `/v1/sports/sport/${sportId}/newsArticles`,
      values,
    )
  }
}
